# باني APK (ApkBuilder)

تطبيق أندرويد (Kotlin، بلا مكتبات خارجية) يحوّل zip لمشروع Gradle إلى APK عبر GitHub Actions.

## البناء الأول من الهاتف (متصفح)
1. أنشئ مستودعاً **خاصاً** على github.com.
2. Add file ▸ Upload files ▸ ارفع `build.yml` ▸ Commit.
3. افتح `build.yml` ▸ أيقونة القلم ▸ غيّر الاسم في الأعلى إلى:
   `.github/workflows/build.yml` ▸ Commit.
4. تبويب Actions: يجب أن يظهر «Build APK» في القائمة الجانبية.
5. Add file ▸ Upload files ▸ ارفع `ApkBuilder.zip` (دون فك ضغطه) ▸ Commit.
6. Actions ▸ آخر تشغيل ▸ Artifacts ▸ `apk-bootstrap` ▸ ثبّت `app-debug.apk`.

## الاستخدام
Token بصلاحيتي repo و workflow + اسم المستودع ▸ «تحقق وتجهيز» ▸ اختيار zip ▸ «ابدأ التحويل» ▸ تثبيت.
