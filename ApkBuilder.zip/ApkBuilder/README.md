# باني APK (ApkBuilder) — الهيكل المبدئي

تطبيق أندرويد (Kotlin، بلا مكتبات خارجية) يحوّل ملف zip لمشروع Gradle إلى APK عبر GitHub Actions، ثم ينزّله ويثبّته.

## بناء التطبيق نفسه من الهاتف (مرة واحدة)
1. في github.com أنشئ مستودعاً **خاصاً** (Private) باسم `apk-builder`.
2. Add file ▸ Create new file ▸ الاسم: `.github/workflows/build.yml` ▸ الصق محتوى الملف `build.yml` المرفق ▸ Commit.
3. Add file ▸ Upload files ▸ اختر `ApkBuilder.zip` ▸ Commit. (يبدأ البناء تلقائياً.)
4. تبويب Actions ▸ آخر تشغيل ▸ Artifacts ▸ نزّل `apk-bootstrap` ▸ فك الضغط وثبّت `app-debug.apk`.

> ارفع ملف zip **واحداً** في كل مرة إلى جذر المستودع. الترتيب مهم: ملف build.yml أولاً ثم الـ zip.

## الاستخدام
1. افتح التطبيق ▸ الصق Token (صلاحيتا `repo` و`workflow`) واسم المستودع ▸ «تحقق وتجهيز».
2. «اختيار ملف zip» (أو «فتح بواسطة» من مدير الملفات) ▸ «ابدأ التحويل».
3. بعد دقائق يظهر APK ▸ تثبيت.

## ما تحويه الحزمة
- `app/` التطبيق، `.github/workflows/build.yml` ملف البناء (نسخة منه في `app/src/main/assets/` يرفعها التطبيق تلقائياً).
- يوقَّع كل APK بمفتاح ثابت يُنشأ أول مرة في `signing/keystore.p12` داخل المستودع، فتعمل التحديثات فوق النسخة المثبّتة.
