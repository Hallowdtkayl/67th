package dev.hub.apkbuilder

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import java.util.zip.ZipFile

/** ما تحتاجه الواجهة من منطق البناء. تُستدعى كلها على الخيط الرئيسي. */
interface FlowListener {
    fun onStatus(text: String)
    fun onBusy(busy: Boolean)
    fun onLog(text: String)
    fun onApks(files: List<File>)
    fun onVerified(summary: String)
}

/** التحقق من المستودع، رفع الحزمة، تشغيل البناء، متابعته، وتنزيل النتيجة. */
class BuildFlow(private val ctx: Context, private val prefs: Prefs, private val ls: FlowListener) {

    companion object {
        const val WORKFLOW = "build.yml"
        const val WORKFLOW_PATH = ".github/workflows/build.yml"
        private const val MAX_WAIT_MS = 50L * 60 * 1000
    }

    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var cancelled = false

    @Volatile
    private var worker: Thread? = null

    val running: Boolean get() = worker?.isAlive == true

    private fun ui(block: () -> Unit) {
        main.post(block)
    }

    private fun status(t: String) = ui { ls.onStatus(t) }

    private fun launch(block: () -> Unit) {
        if (running) return
        cancelled = false
        ui { ls.onBusy(true) }
        val t = Thread {
            try {
                block()
            } catch (e: GhException) {
                status("✗ " + (e.message ?: "خطأ"))
            } catch (e: InterruptedException) {
                status("أُوقفت المتابعة.")
            } catch (e: Exception) {
                status("✗ تعذّر الاتصال أو حدث خطأ: " + (e.message ?: e.javaClass.simpleName))
            } finally {
                ui { ls.onBusy(false) }
            }
        }
        worker = t
        t.start()
    }

    fun cancel() {
        cancelled = true
        worker?.interrupt()
    }

    // ---------- 1) التحقق وتجهيز المستودع ----------

    private fun parseRepo(text: String, login: String): Pair<String, String> {
        var s = text.trim()
            .removePrefix("https://github.com/").removePrefix("http://github.com/")
            .removePrefix("github.com/").removeSuffix("/").removeSuffix(".git")
        if (s.isEmpty()) s = "apk-builder"
        val parts = s.split('/')
        return if (parts.size >= 2) Pair(parts[0], parts[1]) else Pair(login, parts[0])
    }

    fun verify(token: String, repoText: String) {
        launch {
            if (token.isBlank()) {
                status("✗ أدخل رمز GitHub (Token) أولاً.")
                return@launch
            }
            status("أتحقق من الرمز…")
            val gh = GitHub(token.trim())
            val login = gh.login()
            val (owner, name) = parseRepo(repoText, login)

            status("أتحقق من المستودع $owner/$name …")
            var info = gh.repo(owner, name)
            var created = false
            if (info == null) {
                if (owner != login) throw GhException(404, "المستودع $owner/$name غير موجود.")
                status("أنشئ المستودع الخاص $name …")
                info = gh.createRepo(name)
                created = true
                Thread.sleep(3000)
            }
            val perms = info.optJSONObject("permissions")
            if (perms != null && !perms.optBoolean("push", true)) {
                throw GhException(403, "لا تملك صلاحية الكتابة في $owner/$name.")
            }
            val branch = info.optString("default_branch", "main").ifEmpty { "main" }
            val isPrivate = info.optBoolean("private", true)

            status("أجهّز ملف البناء…")
            val expected = ctx.assets.open("build.yml").bufferedReader(Charsets.UTF_8).use { it.readText() }
                .replace("\r\n", "\n")
            val existing = gh.getFile(owner, name, WORKFLOW_PATH, branch)
            var wfState = "جاهز"
            if (existing == null || created) {
                putWorkflow(gh, owner, name, branch, expected, existing?.optString("sha"))
                wfState = "تم إنشاؤه"
            } else {
                val cur = String(
                    android.util.Base64.decode(existing.optString("content").replace("\n", ""), android.util.Base64.DEFAULT),
                    Charsets.UTF_8
                ).replace("\r\n", "\n")
                if (cur != expected) {
                    putWorkflow(gh, owner, name, branch, expected, existing.optString("sha"))
                    wfState = "تم تحديثه"
                }
            }

            prefs.token = token
            prefs.repo = "$owner/$name"
            prefs.branch = branch
            prefs.verified = true
            val vis = if (isPrivate) "خاص" else "عام ⚠ (الأفضل جعله خاصاً لأن مفتاح التوقيع يُحفظ فيه)"
            val summary = "✓ متصل كـ $login\nالمستودع: $owner/$name ($vis)\nملف البناء: $wfState"
            ui { ls.onVerified(summary) }
        }
    }

    private fun putWorkflow(gh: GitHub, owner: String, name: String, branch: String, text: String, sha: String?) {
        var lastError: GhException? = null
        for (i in 1..5) {
            try {
                gh.putText(owner, name, WORKFLOW_PATH, branch, "Add build workflow", text, sha)
                return
            } catch (e: GhException) {
                lastError = e
                if (e.code != 404 && e.code != 409) break
                Thread.sleep(2500)
            }
        }
        val hint = if (lastError?.code == 404 || lastError?.code == 403)
            "\nتأكد أن الرمز يملك الصلاحيتين repo و workflow." else ""
        throw GhException(lastError?.code ?: 0, (lastError?.message ?: "فشل رفع ملف البناء") + hint)
    }

    // ---------- 2) رفع الحزمة وتشغيل البناء ----------

    private fun newJobId(): String {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val rnd = Random()
        val tail = StringBuilder()
        repeat(4) { tail.append("abcdefghijklmnopqrstuvwxyz0123456789"[rnd.nextInt(36)]) }
        return "$stamp-$tail"
    }

    fun submit(zip: File, displayName: String, release: Boolean) {
        launch {
            val (owner, name) = prefs.repo.split('/').let { Pair(it[0], it[1]) }
            val gh = GitHub(prefs.token)
            val job = newJobId()
            val path = "jobs/$job/project.zip"

            status("أرفع الحزمة إلى GitHub (${zip.length() / 1024} ك.ب)…")
            gh.putFile(owner, name, path, prefs.branch, "job $job", zip)

            status("أشغّل البناء في السحابة…")
            var err: GhException? = null
            var started = false
            for (i in 1..8) {
                try {
                    gh.dispatch(owner, name, WORKFLOW, prefs.branch,
                        mapOf("job" to job, "variant" to (if (release) "release" else "debug")))
                    started = true
                    break
                } catch (e: GhException) {
                    err = e
                    if (e.code != 404 && e.code != 422) throw e
                    Thread.sleep(4000)
                }
            }
            if (!started) {
                throw GhException(err?.code ?: 0,
                    (err?.message ?: "فشل تشغيل البناء") + "\nاضغط «تحقق وتجهيز» ثم أعد المحاولة.")
            }
            prefs.pendingJob = job
            prefs.pendingStart = System.currentTimeMillis()
            prefs.pendingName = displayName
            watch(gh, owner, name, job)
        }
    }

    /** يستأنف متابعة بناء بدأ سابقاً (بعد إغلاق التطبيق). */
    fun resume() {
        val job = prefs.pendingJob
        if (job.isEmpty() || prefs.repo.isEmpty() || prefs.token.isEmpty()) return
        launch {
            val (owner, name) = prefs.repo.split('/').let { Pair(it[0], it[1]) }
            status("أستأنف متابعة البناء ($job)…")
            watch(GitHub(prefs.token), owner, name, job)
        }
    }

    // ---------- 3) المتابعة والتنزيل ----------

    private fun watch(gh: GitHub, owner: String, name: String, job: String) {
        val started = prefs.pendingStart.let { if (it == 0L) System.currentTimeMillis() else it }
        val title = "build $job"

        var runId = -1L
        var waited = 0
        while (runId < 0) {
            val r = gh.findRun(owner, name, WORKFLOW, title)
            if (r != null) {
                runId = r.getLong("id")
            } else {
                waited++
                if (waited > 30) throw GhException(0, "لم يبدأ البناء. افتح تبويب Actions في المستودع وتأكد أنه مفعّل.")
                status("بانتظار بدء البناء…")
                Thread.sleep(4000)
            }
        }

        var conclusion = ""
        while (true) {
            val r = gh.run(owner, name, runId)
            val st = r.optString("status")
            val secs = (System.currentTimeMillis() - started) / 1000
            val clock = String.format(Locale.US, "%d:%02d", secs / 60, secs % 60)
            if (st == "completed") {
                conclusion = r.optString("conclusion")
                break
            }
            if (System.currentTimeMillis() - started > MAX_WAIT_MS) {
                throw GhException(0, "انتهت مهلة الانتظار (50 دقيقة). افتح Actions لمعرفة الحالة.")
            }
            val step = if (st == "in_progress") {
                try { gh.currentStep(owner, name, runId) } catch (e: GhException) { "" }
            } else ""
            val label = if (st == "queued" || st == "waiting" || st == "pending") "في قائمة الانتظار" else "جارٍ البناء"
            status("$label… $clock" + (if (step.isNotEmpty()) "\n» $step" else ""))
            Thread.sleep(6000)
        }

        if (cancelled) return
        if (conclusion == "success") {
            status("البناء نجح. أنزّل ملف APK…")
            val files = fetchApks(gh, owner, name, runId, job)
            cleanup(gh, owner, name, job)
            prefs.clearPending()
            status("✓ جاهز: ${files.size} ملف APK")
            ui { ls.onApks(files) }
        } else {
            status("✗ فشل البناء ($conclusion). أنزّل سجل الأخطاء…")
            val text = fetchLog(gh, owner, name, runId, job)
            cleanup(gh, owner, name, job)
            prefs.clearPending()
            ui { ls.onLog(text) }
            status("✗ فشل البناء. السجل أدناه؛ انسخه وأرسله لـ Claude لإصلاح المشروع.")
        }
    }

    private fun fetchApks(gh: GitHub, owner: String, name: String, runId: Long, job: String): List<File> {
        val id = gh.findArtifact(owner, name, runId, "apk-$job")
        if (id < 0) throw GhException(0, "انتهى البناء لكن لم أجد ملف APK ضمن النتائج.")
        val tmp = File(ctx.cacheDir, "artifact-$job.zip")
        gh.downloadArtifact(owner, name, id, tmp)
        val dir = File(ctx.filesDir, "apks/$job")
        dir.mkdirs()
        val out = ArrayList<File>()
        ZipFile(tmp).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (e.isDirectory || !e.name.endsWith(".apk")) continue
                val f = File(dir, File(e.name).name)
                z.getInputStream(e).use { ins -> f.outputStream().use { ins.copyTo(it, 64 * 1024) } }
                out.add(f)
            }
        }
        tmp.delete()
        if (out.isEmpty()) throw GhException(0, "ملف النتائج لا يحتوي APK.")
        return out
    }

    private fun fetchLog(gh: GitHub, owner: String, name: String, runId: Long, job: String): String {
        return try {
            val id = gh.findArtifact(owner, name, runId, "log-$job")
            if (id < 0) return "لا يوجد سجل مرفوع. افتح تبويب Actions في المستودع لقراءة السجل الكامل."
            val tmp = File(ctx.cacheDir, "log-$job.zip")
            gh.downloadArtifact(owner, name, id, tmp)
            var text = ""
            ZipFile(tmp).use { z ->
                val e = z.entries().asSequence().firstOrNull { !it.isDirectory }
                if (e != null) text = z.getInputStream(e).bufferedReader(Charsets.UTF_8).use { it.readText() }
            }
            tmp.delete()
            tailOf(text)
        } catch (e: Exception) {
            "تعذّر تنزيل السجل: " + (e.message ?: "")
        }
    }

    /** آخر الأسطر مع إبراز أسطر الأخطاء. */
    private fun tailOf(text: String): String {
        val lines = text.lines()
        val errors = lines.filter {
            it.startsWith("e: ") || it.contains("error:", true) || it.contains("FAILED") ||
                it.contains("What went wrong") || it.contains("::error")
        }.take(25)
        val tail = lines.takeLast(40)
        val sb = StringBuilder()
        if (errors.isNotEmpty()) {
            sb.append("— أهم الأخطاء —\n").append(errors.joinToString("\n")).append("\n\n")
        }
        sb.append("— آخر السجل —\n").append(tail.joinToString("\n"))
        return sb.toString()
    }

    private fun cleanup(gh: GitHub, owner: String, name: String, job: String) {
        try {
            val path = "jobs/$job/project.zip"
            val f = gh.getFile(owner, name, path, prefs.branch) ?: return
            gh.deleteFile(owner, name, path, prefs.branch, f.getString("sha"))
        } catch (e: Exception) {
            // تنظيف اختياري
        }
    }

    /** يلغي التشغيل الجاري في GitHub (إن وُجد) ويمسح الحالة المعلّقة. */
    fun abortPending() {
        val job = prefs.pendingJob
        cancel()
        Thread {
            try {
                if (job.isNotEmpty() && prefs.repo.isNotEmpty()) {
                    val (owner, name) = prefs.repo.split('/').let { Pair(it[0], it[1]) }
                    val gh = GitHub(prefs.token)
                    val r = gh.findRun(owner, name, WORKFLOW, "build $job")
                    if (r != null) gh.cancelRun(owner, name, r.getLong("id"))
                }
            } catch (e: Exception) {
                // لا بأس
            }
            prefs.clearPending()
        }.start()
    }
}
