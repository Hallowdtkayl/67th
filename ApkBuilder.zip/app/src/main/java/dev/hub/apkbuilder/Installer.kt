package dev.hub.apkbuilder

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.File

object Installer {

    const val ACTION = "dev.hub.apkbuilder.INSTALL_RESULT"

    /** تُستدعى من الـ receiver برسالة النتيجة (على الخيط الرئيسي). */
    @Volatile
    var onResult: ((String) -> Unit)? = null

    /** يثبّت الملف عبر جلسة PackageInstaller؛ يظهر بعدها حوار التأكيد من النظام. */
    fun install(ctx: Context, apk: File) {
        val installer = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        params.setSize(apk.length())
        val id = installer.createSession(params)
        val session = installer.openSession(id)
        try {
            apk.inputStream().use { ins ->
                session.openWrite("base.apk", 0, apk.length()).use { out ->
                    ins.copyTo(out, 64 * 1024)
                    session.fsync(out)
                }
            }
            val intent = Intent(ctx, InstallReceiver::class.java).setAction(ACTION)
            val pending = PendingIntent.getBroadcast(
                ctx, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
            )
            session.commit(pending.intentSender)
        } catch (e: Exception) {
            session.abandon()
            throw e
        } finally {
            session.close()
        }
    }

    /** ينسخ APK إلى مجلد التنزيلات (Download/ApkBuilder) ليسهل العثور عليه أو مشاركته. */
    fun saveToDownloads(ctx: Context, apk: File, displayName: String): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, displayName)
            put(MediaStore.Downloads.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ApkBuilder")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
        val out = resolver.openOutputStream(uri) ?: return false
        out.use { o -> apk.inputStream().use { it.copyTo(o, 64 * 1024) } }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return true
    }
}

/** يستقبل حالة التثبيت: يفتح حوار التأكيد أو يعرض سبب الفشل بالعربية. */
class InstallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, -999)
        val detail = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            val confirm: Intent? = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent.getParcelableExtra(Intent.EXTRA_INTENT)
            }
            if (confirm != null) {
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(confirm)
            }
            return
        }
        val msg = when (status) {
            PackageInstaller.STATUS_SUCCESS -> "تم التثبيت بنجاح ✓"
            PackageInstaller.STATUS_FAILURE_CONFLICT ->
                "تعارض: يوجد إصدار مثبّت بتوقيع مختلف. احذف التطبيق القديم أولاً ثم أعد التثبيت."
            PackageInstaller.STATUS_FAILURE_INCOMPATIBLE ->
                "الحزمة غير متوافقة مع جهازك (إصدار أندرويد أو المعمارية)."
            PackageInstaller.STATUS_FAILURE_ABORTED -> "أُلغي التثبيت."
            PackageInstaller.STATUS_FAILURE_BLOCKED ->
                "حظر النظام التثبيت (سياسة الجهاز أو Play Protect). $detail"
            PackageInstaller.STATUS_FAILURE_STORAGE -> "مساحة التخزين غير كافية."
            PackageInstaller.STATUS_FAILURE_INVALID -> "ملف APK غير صالح أو تالف. $detail"
            else -> "فشل التثبيت ($status). $detail"
        }
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
        Installer.onResult?.invoke(msg)
    }
}
