package dev.hub.apkbuilder

import java.io.File
import java.util.zip.ZipFile

/** نتيجة فحص ملف zip قبل رفعه. */
class ZipInfo(
    val ok: Boolean,
    val appId: String,
    val appName: String,
    val modules: List<String>,
    val files: Int,
    val warnings: List<String>,
    val errors: List<String>
)

/** يتحقق أن الملف مشروع Gradle لتطبيق أندرويد، ويستخرج اسم الحزمة والتطبيق. */
object ZipInspector {

    const val MAX_BYTES = 40L * 1024 * 1024
    private const val MAX_TEXT = 256 * 1024

    private val settingsRe = Regex("(^|.*/)settings\\.gradle(\\.kts)?$")

    fun inspect(file: File): ZipInfo {
        val errors = ArrayList<String>()
        val warnings = ArrayList<String>()
        if (file.length() > MAX_BYTES) {
            errors.add("حجم الملف أكبر من 40 ميغابايت. أرسل المصدر فقط دون مجلدات build أو ملفات APK.")
        }
        val zf = try {
            ZipFile(file)
        } catch (e: Exception) {
            errors.add("الملف ليس zip صالحاً: ${e.message}")
            return ZipInfo(false, "", "", emptyList(), 0, warnings, errors)
        }
        return zf.use { z ->
            val names = ArrayList<String>()
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                if (!e.isDirectory) names.add(e.name.replace('\\', '/'))
            }
            val settings = names.filter { settingsRe.matches(it) }.minByOrNull { it.count { c -> c == '/' } }
            if (settings == null) {
                errors.add("لم أجد settings.gradle أو settings.gradle.kts. هذه ليست حزمة مشروع أندرويد (Gradle).")
                return@use ZipInfo(false, "", "", emptyList(), names.size, warnings, errors)
            }
            val root = settings.substringBeforeLast('/', "").let { if (it.isEmpty()) "" else "$it/" }

            // وحدات التطبيق: أي build.gradle(.kts) مباشر داخل مجلد فرعي يطبّق com.android.application
            val modules = ArrayList<String>()
            var appId = ""
            var appManifestLabel = ""
            var moduleDir = ""
            for (n in names) {
                if (!n.startsWith(root)) continue
                val rel = n.substring(root.length)
                val parts = rel.split('/')
                if (parts.size != 2) continue
                if (parts[1] != "build.gradle" && parts[1] != "build.gradle.kts") continue
                val text = readText(z, n)
                if (!text.contains("com.android.application")) continue
                modules.add(parts[0])
                if (appId.isEmpty()) {
                    moduleDir = root + parts[0] + "/"
                    appId = firstGroup(text, "applicationId\\s*=?\\s*[\"']([^\"']+)[\"']")
                        .ifEmpty { firstGroup(text, "namespace\\s*=?\\s*[\"']([^\"']+)[\"']") }
                }
            }
            if (modules.isEmpty()) {
                errors.add("لم أجد وحدة تطبيق (com.android.application) في المشروع.")
            }

            var appName = ""
            if (moduleDir.isNotEmpty()) {
                val manifest = names.firstOrNull { it == moduleDir + "src/main/AndroidManifest.xml" }
                if (manifest == null) {
                    errors.add("ملف AndroidManifest.xml مفقود في ${moduleDir}src/main.")
                } else {
                    appManifestLabel = firstGroup(readText(z, manifest), "<application[^>]*android:label=\"([^\"]+)\"")
                    appName = resolveLabel(z, names, moduleDir, appManifestLabel)
                }
            }

            if (names.any { it.endsWith(".apk") }) warnings.add("الحزمة تحتوي ملفات APK؛ يفضّل حذفها لتقليل الحجم.")
            if (names.any { it.contains("/build/intermediates/") || it.startsWith("build/intermediates/") }) {
                warnings.add("الحزمة تحتوي مجلد build؛ يفضّل إرسال المصدر فقط.")
            }
            if (names.none { it.startsWith(root + "gradle/wrapper/gradle-wrapper.properties") }) {
                warnings.add("لا يوجد gradle-wrapper.properties: سيُستخدم Gradle 8.9 افتراضياً.")
            }

            ZipInfo(errors.isEmpty(), appId, appName, modules, names.size, warnings, errors)
        }
    }

    private fun resolveLabel(z: ZipFile, names: List<String>, moduleDir: String, label: String): String {
        if (!label.startsWith("@string/")) return label
        val key = label.removePrefix("@string/")
        val strings = names.filter { it.startsWith(moduleDir + "src/main/res/values") && it.endsWith("strings.xml") }
        for (n in strings) {
            val v = firstGroup(readText(z, n), "<string\\s+name=\"" + Regex.escape(key) + "\"[^>]*>([^<]*)</string>")
            if (v.isNotEmpty()) return v
        }
        return key
    }

    private fun readText(z: ZipFile, name: String): String {
        val e = z.getEntry(name) ?: return ""
        if (e.size > MAX_TEXT) return ""
        return z.getInputStream(e).bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private fun firstGroup(text: String, pattern: String): String =
        Regex(pattern).find(text)?.groupValues?.get(1)?.trim() ?: ""
}
