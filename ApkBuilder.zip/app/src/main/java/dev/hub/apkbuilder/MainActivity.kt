package dev.hub.apkbuilder

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * الهيكل المبدئي للواجهة: يربط كل أجزاء التطبيق ببعضها بعناصر بسيطة.
 * الواجهة الكاملة (ألوان، بطاقات، نسخ السجل، قائمة APK...) تُبنى فوق هذا الهيكل.
 */
class MainActivity : Activity(), FlowListener {

    private val reqPick = 11

    private lateinit var prefs: Prefs
    private lateinit var flow: BuildFlow

    private lateinit var tokenEt: EditText
    private lateinit var repoEt: EditText
    private lateinit var verifyBtn: Button
    private lateinit var pickBtn: Button
    private lateinit var zipTv: TextView
    private lateinit var buildBtn: Button
    private lateinit var statusTv: TextView
    private lateinit var logTv: TextView
    private lateinit var installBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var stopBtn: Button
    private lateinit var copyBtn: Button

    private var zipInfo: ZipInfo? = null
    private var apks: List<File> = emptyList()
    private var busy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- دورة الحياة ----------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        flow = BuildFlow(this, prefs, this)
        setContentView(buildUi())
        tokenEt.setText(prefs.token)
        repoEt.setText(prefs.repo)

        val cached = File(cacheDir, "pick.zip")
        if (cached.exists() && prefs.pickName.isNotEmpty()) inspect(cached, prefs.pickName)

        Installer.onResult = { msg -> runOnUiThread { statusTv.text = msg } }
        handleIncoming(intent)
        if (prefs.pendingJob.isNotEmpty() && !flow.running) flow.resume()
        refreshButtons()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    override fun onDestroy() {
        Installer.onResult = null
        super.onDestroy()
    }

    // ---------- الواجهة ----------

    private fun text(t: String, size: Float = 15f, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun button(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        setOnClickListener { onClick() }
    }

    private fun input(hint: String, password: Boolean) = EditText(this).apply {
        this.hint = hint
        setSingleLine()
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        inputType = if (password) {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(24))
        }
        root.addView(text("باني APK", 24f, true))
        root.addView(text("حوّل مشروع Gradle (ملف zip) إلى APK عبر GitHub Actions."))

        root.addView(text("١) الاتصال بـ GitHub", 17f, true))
        tokenEt = input("Token (ghp_… أو github_pat_…)", true)
        repoEt = input("owner/repo أو اسم المستودع فقط", false)
        root.addView(tokenEt)
        root.addView(repoEt)
        verifyBtn = button("تحقق وتجهيز المستودع") {
            flow.verify(tokenEt.text.toString(), repoEt.text.toString())
        }
        root.addView(verifyBtn)

        root.addView(text("٢) الحزمة", 17f, true))
        pickBtn = button("اختيار ملف zip") { pickZip() }
        root.addView(pickBtn)
        zipTv = text("لم يُختر ملف بعد.")
        root.addView(zipTv)

        root.addView(text("٣) التحويل", 17f, true))
        buildBtn = button("ابدأ التحويل إلى APK") { startBuild() }
        root.addView(buildBtn)
        statusTv = text("")
        root.addView(statusTv)
        stopBtn = button("إيقاف") { flow.abortPending(); statusTv.text = "أُوقف." }
        root.addView(stopBtn)

        installBtn = button("تثبيت APK") { installFirst() }
        saveBtn = button("حفظ في التنزيلات") { saveFirst() }
        root.addView(installBtn)
        root.addView(saveBtn)

        logTv = text("", 12f).apply {
            typeface = android.graphics.Typeface.MONOSPACE
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setTextIsSelectable(true)
        }
        root.addView(logTv)
        copyBtn = button("نسخ السجل") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("log", logTv.text))
            toast("نُسخ السجل")
        }
        root.addView(copyBtn)

        val scroll = ScrollView(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            clipToPadding = false
            addView(root)
            // targetSdk 35 يفرض العرض من الحافة إلى الحافة: نعوّض أشرطة النظام ولوحة المفاتيح
            if (Build.VERSION.SDK_INT >= 30) setOnApplyWindowInsetsListener { v, insets ->
                val b = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout() or WindowInsets.Type.ime()
                )
                v.setPadding(b.left, b.top, b.right, b.bottom)
                insets
            }
        }
        return scroll
    }

    private fun refreshButtons() {
        val z = zipInfo
        verifyBtn.isEnabled = !busy
        pickBtn.isEnabled = !busy
        buildBtn.isEnabled = !busy && prefs.verified && z != null && z.ok
        installBtn.visibility = if (apks.isEmpty()) View.GONE else View.VISIBLE
        saveBtn.visibility = if (apks.isEmpty()) View.GONE else View.VISIBLE
        stopBtn.visibility = if (busy) View.VISIBLE else View.GONE
        copyBtn.visibility = if (logTv.text.isEmpty()) View.GONE else View.VISIBLE
    }

    // ---------- اختيار الحزمة ----------

    private fun pickZip() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType("*/*")
            .putExtra(
                Intent.EXTRA_MIME_TYPES,
                arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")
            )
        startActivityForResult(i, reqPick)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqPick && resultCode == RESULT_OK) data?.data?.let { loadZip(it) }
    }

    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_VIEW -> i.data
            Intent.ACTION_SEND -> if (Build.VERSION.SDK_INT >= 33) {
                i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                i.getParcelableExtra(Intent.EXTRA_STREAM)
            }
            else -> null
        }
        if (uri != null) {
            setIntent(Intent())
            loadZip(uri)
        }
    }

    /** ينسخ الملف المختار إلى الكاش (لمعرفة حجمه الدقيق ورفعه بتدفق) ثم يفحصه. */
    private fun loadZip(uri: Uri) {
        zipTv.text = "أقرأ الملف…"
        Thread {
            try {
                var name = "project.zip"
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) name = c.getString(0) ?: name
                }
                val dest = File(cacheDir, "pick.zip")
                val ins = contentResolver.openInputStream(uri) ?: throw java.io.IOException("تعذّر فتح الملف")
                ins.use { i -> dest.outputStream().use { o -> i.copyTo(o, 64 * 1024) } }
                prefs.pickName = name
                runOnUiThread { inspect(dest, name) }
            } catch (e: Exception) {
                runOnUiThread { zipTv.text = "✗ تعذّر قراءة الملف: ${e.message}" }
            }
        }.start()
    }

    private fun inspect(file: File, name: String) {
        Thread {
            val info = ZipInspector.inspect(file)
            runOnUiThread {
                zipInfo = info
                val sb = StringBuilder("الملف: $name\n")
                if (info.ok) {
                    sb.append("التطبيق: ${info.appName.ifEmpty { "—" }}\n")
                    sb.append("المعرّف: ${info.appId.ifEmpty { "—" }}\n")
                    sb.append("الوحدات: ${info.modules.joinToString()}\n")
                }
                info.errors.forEach { sb.append("✗ ").append(it).append('\n') }
                info.warnings.forEach { sb.append("⚠ ").append(it).append('\n') }
                zipTv.text = sb.toString().trim()
                refreshButtons()
            }
        }.start()
    }

    // ---------- البناء والتثبيت ----------

    private fun startBuild() {
        val info = zipInfo
        val file = File(cacheDir, "pick.zip")
        if (info == null || !info.ok || !file.exists()) {
            toast("اختر ملف zip صالحاً أولاً")
            return
        }
        apks = emptyList()
        logTv.text = ""
        flow.submit(file, prefs.pickName, false)
        refreshButtons()
    }

    private fun installFirst() {
        val f = apks.firstOrNull() ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            toast("فعّل «السماح بتثبيت التطبيقات» لهذا التطبيق ثم عد واضغط تثبيت")
            startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
            )
            return
        }
        try {
            Installer.install(this, f)
        } catch (e: Exception) {
            statusTv.text = "✗ تعذّر بدء التثبيت: ${e.message}"
        }
    }

    private fun saveFirst() {
        val f = apks.firstOrNull() ?: return
        val ok = try {
            Installer.saveToDownloads(this, f, f.name)
        } catch (e: Exception) {
            false
        }
        toast(if (ok) "حُفظ في التنزيلات/ApkBuilder" else "تعذّر الحفظ")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ---------- FlowListener ----------

    override fun onStatus(text: String) {
        statusTv.text = text
    }

    override fun onBusy(busy: Boolean) {
        this.busy = busy
        refreshButtons()
    }

    override fun onLog(text: String) {
        logTv.text = text
        refreshButtons()
    }

    override fun onApks(files: List<File>) {
        apks = files
        refreshButtons()
    }

    override fun onVerified(summary: String) {
        statusTv.text = summary
        refreshButtons()
    }
}
