package dev.hub.apkbuilder

import android.util.Base64
import android.util.Base64OutputStream
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class GhException(val code: Int, message: String) : Exception(message)

/** عميل صغير لواجهة GitHub REST بدون أي مكتبات خارجية. */
class GitHub(private val token: String) {

    private val api = "https://api.github.com"

    // ---------- الأساسيات ----------

    private fun open(method: String, url: String, withAuth: Boolean): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 60000
        c.instanceFollowRedirects = false
        c.setRequestProperty("User-Agent", "ApkBuilder-Android")
        if (withAuth) {
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            c.setRequestProperty("Authorization", "Bearer $token")
        }
        return c
    }

    private class Reply(val code: Int, val text: String)

    private fun read(c: HttpURLConnection): Reply {
        val code = c.responseCode
        val stream = if (code >= 400) c.errorStream else c.inputStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        return Reply(code, text)
    }

    private fun request(method: String, path: String, body: String?): Reply {
        var last: IOException? = null
        val tries = if (method == "GET") 3 else 1
        for (i in 1..tries) {
            val c = open(method, api + path, true)
            try {
                if (body != null) {
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                }
                return read(c)
            } catch (e: IOException) {
                last = e
                if (i < tries) Thread.sleep(1500)
            } finally {
                c.disconnect()
            }
        }
        throw last ?: IOException("network")
    }

    private fun errorText(code: Int, text: String): String {
        val msg = try {
            JSONObject(text).optString("message", "")
        } catch (e: Exception) {
            ""
        }
        val hint = when (code) {
            401 -> "الرمز (Token) غير صالح أو منتهي."
            403 -> "الرمز لا يملك صلاحية كافية (يلزم repo و workflow) أو تجاوزت حد الطلبات."
            404 -> "غير موجود، أو الرمز لا يملك صلاحية الوصول إليه."
            else -> ""
        }
        return listOf("GitHub $code", hint, msg).filter { it.isNotEmpty() }.joinToString(" — ")
    }

    private fun call(method: String, path: String, body: JSONObject? = null): JSONObject {
        val r = request(method, path, body?.toString())
        if (r.code !in 200..299) throw GhException(r.code, errorText(r.code, r.text))
        if (r.text.isBlank()) return JSONObject()
        return try {
            JSONObject(r.text)
        } catch (e: Exception) {
            JSONObject()
        }
    }

    /** نفس call لكن يعيد null عند 404. */
    private fun callOrNull(path: String): JSONObject? {
        val r = request("GET", path, null)
        if (r.code == 404) return null
        if (r.code !in 200..299) throw GhException(r.code, errorText(r.code, r.text))
        return JSONObject(r.text)
    }

    // ---------- الحساب والمستودع ----------

    fun login(): String = call("GET", "/user").getString("login")

    fun repo(owner: String, name: String): JSONObject? = callOrNull("/repos/$owner/$name")

    fun createRepo(name: String): JSONObject {
        val body = JSONObject()
            .put("name", name)
            .put("private", true)
            .put("auto_init", true)
            .put("description", "APK builds (created by ApkBuilder)")
        return call("POST", "/user/repos", body)
    }

    // ---------- الملفات ----------

    fun getFile(owner: String, name: String, path: String, ref: String): JSONObject? =
        callOrNull("/repos/$owner/$name/contents/$path?ref=$ref")

    fun putText(owner: String, name: String, path: String, branch: String,
                message: String, text: String, sha: String?): JSONObject {
        val body = JSONObject()
            .put("message", message)
            .put("branch", branch)
            .put("content", Base64.encodeToString(text.toByteArray(Charsets.UTF_8), Base64.NO_WRAP))
        if (!sha.isNullOrEmpty()) body.put("sha", sha)
        return call("PUT", "/repos/$owner/$name/contents/$path", body)
    }

    /** يرفع ملفاً كبيراً بتدفق (Base64 أثناء الكتابة) دون تحميله كله في الذاكرة. يعيد sha. */
    fun putFile(owner: String, name: String, path: String, branch: String,
                message: String, file: File): String {
        val prefix = ("{\"message\":" + JSONObject.quote(message) +
            ",\"branch\":" + JSONObject.quote(branch) + ",\"content\":\"").toByteArray(Charsets.UTF_8)
        val suffix = "\"}".toByteArray(Charsets.UTF_8)
        val b64Len = 4L * ((file.length() + 2) / 3)
        val total = prefix.size + b64Len + suffix.size

        val c = open("PUT", "$api/repos/$owner/$name/contents/$path", true)
        try {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setFixedLengthStreamingMode(total)
            val out = c.outputStream
            out.write(prefix)
            val enc = Base64OutputStream(out, Base64.NO_WRAP or Base64.NO_CLOSE)
            file.inputStream().use { it.copyTo(enc, 32 * 1024) }
            enc.close()
            out.write(suffix)
            out.flush()
            out.close()
            val r = read(c)
            if (r.code !in 200..299) throw GhException(r.code, errorText(r.code, r.text))
            return JSONObject(r.text).getJSONObject("content").getString("sha")
        } finally {
            c.disconnect()
        }
    }

    /** حذف ملف (محاولة اختيارية؛ الفشل غير مهم). */
    fun deleteFile(owner: String, name: String, path: String, branch: String, sha: String) {
        val body = JSONObject().put("message", "cleanup $path").put("branch", branch).put("sha", sha)
        call("DELETE", "/repos/$owner/$name/contents/$path", body)
    }

    // ---------- Actions ----------

    fun dispatch(owner: String, name: String, workflow: String, ref: String, inputs: Map<String, String>) {
        val inp = JSONObject()
        for ((k, v) in inputs) inp.put(k, v)
        call("POST", "/repos/$owner/$name/actions/workflows/$workflow/dispatches",
            JSONObject().put("ref", ref).put("inputs", inp))
    }

    /** يبحث عن التشغيل الذي عنوانه (run-name) يساوي title. */
    fun findRun(owner: String, name: String, workflow: String, title: String): JSONObject? {
        val o = call("GET", "/repos/$owner/$name/actions/workflows/$workflow/runs?event=workflow_dispatch&per_page=30")
        val arr = o.optJSONArray("workflow_runs") ?: return null
        for (i in 0 until arr.length()) {
            val r = arr.getJSONObject(i)
            if (r.optString("display_title") == title) return r
        }
        return null
    }

    fun run(owner: String, name: String, id: Long): JSONObject =
        call("GET", "/repos/$owner/$name/actions/runs/$id")

    /** اسم الخطوة الجارية الآن في المهمة (أو فارغ). */
    fun currentStep(owner: String, name: String, runId: Long): String {
        val o = call("GET", "/repos/$owner/$name/actions/runs/$runId/jobs")
        val jobs = o.optJSONArray("jobs") ?: return ""
        if (jobs.length() == 0) return ""
        val steps = jobs.getJSONObject(0).optJSONArray("steps") ?: return ""
        for (i in 0 until steps.length()) {
            val s = steps.getJSONObject(i)
            if (s.optString("status") == "in_progress") return s.optString("name")
        }
        return ""
    }

    fun cancelRun(owner: String, name: String, runId: Long) {
        call("POST", "/repos/$owner/$name/actions/runs/$runId/cancel")
    }

    /** معرّف الـ artifact باسم معيّن في تشغيل معيّن، أو -1. */
    fun findArtifact(owner: String, name: String, runId: Long, artifactName: String): Long {
        val o = call("GET", "/repos/$owner/$name/actions/runs/$runId/artifacts?per_page=50")
        val arr = o.optJSONArray("artifacts") ?: return -1L
        for (i in 0 until arr.length()) {
            val a = arr.getJSONObject(i)
            if (a.optString("name") == artifactName && !a.optBoolean("expired")) return a.getLong("id")
        }
        return -1L
    }

    /** ينزّل artifact (zip). التحويل إلى عنوان التخزين يتم يدوياً بدون ترويسة الاعتماد. */
    fun downloadArtifact(owner: String, name: String, artifactId: Long, dest: File) {
        var url = "$api/repos/$owner/$name/actions/artifacts/$artifactId/zip"
        var auth = true
        for (hop in 0 until 5) {
            val c = open("GET", url, auth)
            try {
                val code = c.responseCode
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    url = c.getHeaderField("Location") ?: throw GhException(code, "إعادة توجيه بلا عنوان")
                    auth = false
                    continue
                }
                if (code != 200) {
                    val t = c.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                    throw GhException(code, errorText(code, t))
                }
                c.inputStream.use { ins -> dest.outputStream().use { outs -> ins.copyTo(outs, 32 * 1024) } }
                return
            } finally {
                c.disconnect()
            }
        }
        throw GhException(0, "تحويلات كثيرة أثناء التنزيل")
    }
}
