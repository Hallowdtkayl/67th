package dev.hub.apkbuilder

import android.content.Context
import android.content.SharedPreferences

/** إعدادات التطبيق وحالة آخر عملية بناء (لاستئناف المتابعة بعد إغلاق التطبيق). */
class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("apkbuilder", Context.MODE_PRIVATE)

    var token: String
        get() = sp.getString("token", "") ?: ""
        set(v) = sp.edit().putString("token", v.trim()).apply()

    /** بالشكل owner/name */
    var repo: String
        get() = sp.getString("repo", "") ?: ""
        set(v) = sp.edit().putString("repo", v.trim()).apply()

    var branch: String
        get() = sp.getString("branch", "main") ?: "main"
        set(v) = sp.edit().putString("branch", v).apply()

    /** نجح «تحقق وتجهيز» لهذا الرمز والمستودع. */
    var verified: Boolean
        get() = sp.getBoolean("verified", false)
        set(v) = sp.edit().putBoolean("verified", v).apply()

    var release: Boolean
        get() = sp.getBoolean("release", false)
        set(v) = sp.edit().putBoolean("release", v).apply()

    /** اسم آخر ملف zip تم اختياره (الملف نفسه محفوظ في الكاش). */
    var pickName: String
        get() = sp.getString("pickName", "") ?: ""
        set(v) = sp.edit().putString("pickName", v).apply()

    // ---------- عملية بناء قيد التنفيذ ----------

    var pendingJob: String
        get() = sp.getString("pendingJob", "") ?: ""
        set(v) = sp.edit().putString("pendingJob", v).apply()

    var pendingStart: Long
        get() = sp.getLong("pendingStart", 0L)
        set(v) = sp.edit().putLong("pendingStart", v).apply()

    var pendingName: String
        get() = sp.getString("pendingName", "") ?: ""
        set(v) = sp.edit().putString("pendingName", v).apply()

    fun clearPending() {
        sp.edit().remove("pendingJob").remove("pendingStart").remove("pendingName").apply()
    }
}
